from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.shortcuts import render, redirect, get_object_or_404, HttpResponse
from .models import Post, Category, Tag, Comment
from django.contrib.auth.decorators import login_required
from django.views.generic import ListView
from django.contrib.auth.mixins import LoginRequiredMixin
from post.models import Post, Comment

# List all posts
class PostListView(ListView):
    model = Post
    template_name = 'post/post_list.html'
    context_object_name = 'posts'


# View for blog details
def post_details(request, id):  # Renaming it to match the URL pattern
    post = get_object_or_404(Post, id=id)
    comments = post.comments.all()

    if request.method == "POST":
        if request.user.is_authenticated:
            text = request.POST.get('text')
            if text:
                Comment.objects.create(post=post, user=request.user, text=text)
                messages.success(request, "Comment added successfully!")
                return redirect('post_details', id=id)  # Fixed redirect
        else:
            messages.error(request, "You need to log in to comment.")
            return redirect('login_view')

    return render(request, 'post/post_details.html', {'post': post, 'comments': comments})


@login_required
def post_create(request):
    categories = Category.objects.all()
    tags = Tag.objects.all()

    if request.method == "POST":
        title = request.POST['title']
        content = request.POST['content']
        category_id = request.POST['category']
        tag_ids = request.POST.getlist('tags')
        image = request.FILES.get('image')

        category = get_object_or_404(Category, id=category_id)
        post = Post.objects.create(title=title, content=content, image=image, category=category, user=request.user)

        for tag_id in tag_ids:
            tag = get_object_or_404(Tag, id=tag_id)
            post.tags.add(tag)

        messages.success(request, "Post created successfully!")
        return redirect('post_details', id=post.id)  # Redirect to post details page

    return render(request, 'post/post_create.html', {'categories': categories, 'tags': tags})


@login_required
def post_delete(request, id):
    post = get_object_or_404(Post, id=id)
    
    if request.user != post.user:
        return HttpResponse("You are not authorized to delete this post.", status=403)

    post.delete()
    messages.success(request, "Post deleted successfully!")
    return redirect('post_list')


@login_required
def update_post(request, id):
    post = get_object_or_404(Post, id=id)
    categories = Category.objects.all()
    tags = Tag.objects.all()

    if request.user != post.user:
        return HttpResponse("You are not authorized to edit this post.", status=403)

    if request.method == "POST":
        post.title = request.POST['title']
        post.content = request.POST['content']
        post.category = get_object_or_404(Category, id=request.POST['category'])

        if 'image' in request.FILES:
            post.image = request.FILES['image']

        post.tags.clear()
        tag_ids = request.POST.getlist('tags')
        for tag_id in tag_ids:
            tag = get_object_or_404(Tag, id=tag_id)
            post.tags.add(tag)

        post.save()
        messages.success(request, "Post updated successfully!")
        return redirect('post_list')

    return render(request, 'post/update_post.html', {'categories': categories, 'tags': tags, "post": post})


def register_view(request):
    if request.method == "POST":
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username is already taken.")
            return redirect('register_view')

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email is already registered.")
            return redirect('register_view')

        user = User.objects.create_user(username=username, email=email, password=password)
        messages.success(request, "Account created successfully!")
        return redirect('login_view')

    return render(request, 'user/register_view.html')


def login_view(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            messages.success(request, "Login successful!")
            return redirect('post_list')
        else:
            messages.error(request, "Invalid credentials.")
            return redirect('login_view')

    return render(request, 'user/login.html')


@login_required
def logout_view(request):
    logout(request)
    messages.success(request, "Logged out successfully.")
    return redirect('login_view')
