from django.urls import path
from .views import *


urlpatterns = [
    path('', PostListView.as_view(), name='post_list'),
    path('register_view/', register_view, name='register_view'),
    path('login_view/', login_view, name='login_view'),
    path('logout_view/', logout_view, name='logout_view'),
    path('post_create/', post_create, name='post_create'),
    path('post_delete/<int:id>/', post_delete, name='post_delete'),
    path('update_post/<int:id>/', update_post, name='update_post'),
    path('post_details/<int:id>/', post_details, name='post_details'),  # Corrected name
]
